<br><br><br><br>
<div class="container">
	<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6">
			<div class="card">
				<div class="card-body">
        <div class="lead">ACCESSO DE CLIENTES</div>
<form class="form-horizontal" role="form" method="post" action="index.php?action=clientaccess">

  <div class="form-group">
    <label for="inputEmail1" class="col-lg-12 control-label">Correo Electronico</label>
    <div class="col-lg-12">
      <input type="email" name="email" class="form-control" id="inputEmail1" placeholder="Correo Electronico">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword1" class="col-lg-12 control-label">Contrase&ntilde;a</label>
    <div class="col-lg-12">
      <input type="password" name="password" class="form-control" id="inputPassword1" placeholder="Contrase&ntilde;a">
    </div>
  </div>
  <div class="form-group">
    <div class="col-lg-12">
      <button type="submit" class="btn btn-block btn-secondary">Registrarme</button>
    </div>
  </div>
</form>
				</div>
			</div>
		</div>
	</div>
</div>
<br><br><br>

